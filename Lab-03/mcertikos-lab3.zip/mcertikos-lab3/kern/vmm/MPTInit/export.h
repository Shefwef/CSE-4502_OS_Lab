#ifndef _INIT_MM_MPTINIT_H_
#define _INIT_MM_MPTINIT_H_

void paging_init(unsigned int);

#endif

