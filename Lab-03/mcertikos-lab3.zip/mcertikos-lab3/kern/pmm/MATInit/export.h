#ifndef _KERN_MM_MALINIT_H_
#define _KERN_MM_MALINIT_H_

#ifdef _KERN_

void pmem_init(unsigned int);

#endif /* _KERN_ */

#endif /* !_KERN_MM_MALINIT_H_ */
