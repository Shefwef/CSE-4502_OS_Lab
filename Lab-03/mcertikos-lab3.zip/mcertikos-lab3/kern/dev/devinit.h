#ifndef _KERN_PREINIT_H_
#define _KERN_PREINIT_H_

#ifdef _KERN_

#include <lib/types.h>

void devinit(uintptr_t);

#endif /* _KERN_ */

#endif /* !_KERN_PREINIT_H_ */
