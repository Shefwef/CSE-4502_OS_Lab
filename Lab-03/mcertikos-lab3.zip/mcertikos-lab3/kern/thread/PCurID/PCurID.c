unsigned int CURID;

unsigned int get_curid(void)
{
	return CURID;
}

void set_curid(unsigned int curid)
{
	CURID = curid;
}
