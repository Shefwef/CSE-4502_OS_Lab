#!/bin/sh

sudo umount /mnt
sudo losetup -d /dev/loop1
