#ifndef _USER_STDLIB_H_
#define _USER_STDLIB_H_

int atoi(const char *buf, int *i);

#endif  /* !_USER_STDLIB_H_ */
